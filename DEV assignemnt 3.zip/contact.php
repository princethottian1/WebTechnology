<!doctype html><html lang="en"><head><meta charset="UTF-8"><title>Prince</title><link rel="stylesheet" type="text/css" href="style.css"/> <meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="zoom.css"> </head> <body><div class="header"> <div class="Container"> <div class="logo"> <anim style="height:100px;"> <img src="dp.png" alt="Display Pic" style="padding-right: 0%;"></anim> </div></div><div class="name"> <font color="white">Prince Paul</font> </div><div class="menu-wrap"> <nav class="menu"> <ul class="clearfix"> <li><a href="index.php">Home</a></li><li> <a href="#">Resume<span class="arrow">&#9660;</span></a> <ul class="sub-menu"> <li><a href="about.php">About</a></li><li><a href="education.php">Education</a></li><li><a href="pe.php">Professional Experiance</a></li><li><a href="Resume.pdf">Download</a></li></ul> </li><li><a href="contact.php">Contact</a></li></ul> </nav></div><div class="menu-wrap"> <nav class="menu"> </nav><div class="banner"><div class="h7"><center>Contact</h7></center></div><div class="w3-container w3-center w3-animate-zoom"><div class="contact1"><table style="width:auto;"><h3>Prince Paul</h3><tr> <td><b>Email:</b></td><td><b><a href="mailto:prince.paul.022@gmail.com">prince.paul.022@gmail.com</a><br></b></td></tr><br><tr> <td><b>Find me on:</b></td><td><b><br></b></td></tr></table> <a href="https://www.facebook.com/prince.paul.022"><img src="fb.png" alt="facebook" style="width:150px;height:120px;"></a> </div><div class="contact"><script>function allValidFunction(emailField){var reg=/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/; if (reg.test(emailField.value)==false){alert('Invalid Email Address'); return false;}return true;}</script> 

<form action="contact.php" method="POST">
 <b>Name:</b> <input name="Name" type="name" placeholder="Your name">
 <br><br><b>Subject:</b> <input name="Subject" type="subject" placeholder="Subject">
 <br><br><b>Reason :</b> <select id="reasonOfContact" name="reason"> </select>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script> 
  <script>var $select=$('#reasonOfContact'); $.getJSON("reason.json", function(data){for(var i=0; i<data['reasonOfContact'].length;i++){$select.append('<option id="'+ data['reasonOfContact'][i]['id']+'">'+ data['reasonOfContact'][i]['name']+'</option>' );}}); </script>
  <br><br><b>Enter Your Email ID:</b> <input name="email" type="text" placeholder="Your email" onblur="allValidFunction(this)"><br><br>
  <br><b>Enter Your Message:</b> <textarea name="message" placeholder="Your message">
  	
  </textarea><br><br><b><button type="submit" name="submit">Send</button><b></b> </b> <br></form></center></div></div></div></table></div></body></html><?php

$link= mysqli_connect("localhost","root","","prince");
if (isset($_POST['submit']))
 {
       $name = $_POST['Name'];
       $subject = ($_POST['Subject']);
       $message = ($_POST['message']);
       $email = $_POST['email'];
       $reason = $_POST['reason'];

       // Mail Stuff
       $to = "prince.paul.022@gmail.com";
       $subject1 = "New Form Submitted";
       $txt = "New Contact form has been Submitted";
       $headers = "From: donotreply@fmt.com" ;


       date_default_timezone_set("America/New_York");
       $timestamp = date('Y-m-d G:i:s');
       
       if (isset($_POST['email'])==true && empty($_POST['email'])==false)
        {
        $email=$_POST['email'];
        if (filter_var($email,FILTER_VALIDATE_EMAIL)==true)
         { 
                    
                    $query="INSERT INTO contact(name,subject,reason,email,message,time_stamp) 
                    values ('$name','$subject','$reason','$email','$message','$timestamp')";
                    $stmt=$link->prepare($query);
                    if($stmt->execute()==true)
                        {
                             //mail($to,$subject1,$txt,$headers);
                             echo "<script>alert(' Submitted Successful')</script>";
                             EXIT();
                             //header('Location:index.php');
                        }
                
        
    }
        else
        {
            echo "<script>alert('Invalid Email Address')</script>";
            die();
        }
    }
}
?>